#right frame
import os
listbox = Listbox(right_frame, selectmode =SINGLE,font=("Arial 10 bold"), width = 22, bg =co3 , fg = co1)
listbox.grid(row = 0, column = 0)

w = Scrollbar(right_frame)
w.grid(row = 0, column = 1)

listbox.config(yscrollcommand = w.set)
w.config(command = listbox.yview)


#os.chdir(r'MUSIC FILES KA ADDRESS')
songs = os.listdir()

def show():
    for i in songs:
        listbox.insert(END,i)

show()
window.mainloop()
